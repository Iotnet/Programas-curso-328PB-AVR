/*
 * ADC_i2c.c
 *
 * Created: 28/01/2022 11:58:15 a. m.
 * Author : Nxtview
 */ 

#define F_CPU 8000000UL
#define BAUDRATE 9600
#define BAUD_PRESCALLER (((F_CPU / (BAUDRATE * 16UL))) - 1)

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <avr/sleep.h>   //se agrega la libreria SLEEP
#include "tmp102.h"

//************************************PARAMETROS*************************************************************
#define minutos 5   //tiempo de transmision en minutos
#define comp_seg 12  //segundos que dura despierto el mcu para restarlos y disminuir el desfase 
#define canal_ADC 3 //canal del ADC a leer
//***********************************************************************************************************
#define bitRate				32

char String1[]="AT$RC\n\r";
char String2[]="AT$SF=";
char String3[]="\n\r";

volatile uint8_t sendflag = 0;
volatile uint8_t ON_flag = 1;
volatile unsigned int millis = 65000;
volatile uint16_t average=0;
volatile uint32_t acumulador= 0;
//volatile uint16_t average=0;
volatile uint32_t acumulador_ADC= 0;
volatile uint16_t period=1010;
volatile uint16_t duty=0;
volatile uint16_t adc_temp=0;
volatile uint16_t counter=0;

void sleepWakeup(void);
void timmer2_init(void);
void ADC_init(void);
uint16_t read_adc(uint8_t channel);
char* add_int(unsigned int var);
uint16_t average_ADC(void);
void read_and_send(void);
void USART_init(void);
unsigned char USART_receive(void);
void USART_send( unsigned char data);
void USART_putstring(char* StringPtr);
void millis_timer0_10();

int main(void)
{
	DDRC |= (1<<DDRC1); //PC1 como salida(para habilitar salida 3.3v)
	DDRE |= (1<<DDRE3);  //PE3 como salida(para habilitar salida 5v)
	cli(); 	// Clear interrupts
	USART_init();		//inicializar UASRT
	timmer2_init();		//inicializar timmer
	I2C_Init(bitRate);
	//millis_timer0_10();
	//read_and_send();

	sei();
	while(1)
	{
		//sleepWakeup();
		sleepWakeup();
		if (sendflag==1)
		{
			read_and_send();
		}
	}
}

ISR( TIMER2_OVF_vect ){
	//cada 1/3 seg
	millis++;
}

void sleepWakeup(void)
{
	unsigned int seg=(minutos*60*3)-(comp_seg*3);
	if(millis >= seg)
	{
		SMCR &= ~(1 << SE); // Disabling sleep
		UCSR0B = (1<<RXEN0)|(1<<TXEN0);
		
		cli();
		I2C_Init(bitRate);
		PORTE |= (1<<PORTE3);
		PORTC |= (1<<PORTC1); //encender regulador 3.3
		_delay_ms(5000);
		
		//ON_flag=0;
		//ON_flag==1
		sendflag=1;
		//sendflag=1;
		//millis = 0;
		
	}
	else
	{
		sei();
		//ADMUX &= ~(1<<REFS0); //Vref off
		//ADCSRA &= ~(1<<ADEN); //ADC disable
		//PRR0 = (1<<PRADC);
		sleep_bod_disable();
		UCSR0B &= ~((1<<RXEN0)|(1<<TXEN0)); //deshabilitar USART
		SMCR |= (1 << SE); //habilitar Sleep-mode
		SMCR |=  (0 << SM2) | (1<< SM1) | (1 << SM0); // Select sleep-mode (Power save)
		sleep_cpu();
	}
}
void timmer2_init(void)
{
	TIMSK2 = 0;
	ASSR |= (1 << AS2); // Habilitar modo asincrono
	TCNT2 = 0;  //set initial counter value
	// Init counter
	OCR2A = 128 + 1;  OCR2B = 0;
	TCCR2A = 0; TCCR2B = 0; // Initialize TIMER2
	TCCR2B |= (1 << CS22) | (0 << CS21) | (1 << CS20); // Setup Prescaler = 128
	TIMSK2 |= (1 << TOIE2) | (0 << OCIE2A) | (0 << OCIE2B);
	while (ASSR & ((1<<TCN2UB)|(1<<TCR2BUB))); 	// Wait for registers update
}

char* add_int(unsigned int var)
{
	char buffer[sizeof(unsigned int)*8+1];
	char temp[17];
	div_t div_result;
	strcpy(temp,String2);
	utoa(var,buffer,16);
	div_result= div(strlen(buffer),2);
	if (div_result.rem==0)
	{
		if (strlen(buffer)==2)
		{
			strcat(temp,"00");
		}
		strcat(temp,buffer);
		return(strcat(temp,String3));
	}
	else
	{
		if (strlen(buffer)==1)
		{
			strcat(temp,"000");
		}
		else if (strlen(buffer)==3)
		{
			strcat(temp,"0");
		}
		strcat(temp,buffer);
		return(strcat(temp,String3));
	}
}
void read_and_send(void)
{
	uint16_t temp_result;
	//uint16_t avg=0;
	
	temp_result = TMP102_readtempC(TMP102_ADDR_GND);
	_delay_ms(500);
	temp_result = TMP102_readtempC(TMP102_ADDR_GND);
	
	
	_delay_ms(1500);
	USART_putstring(String1);  //AT$RC
	_delay_ms(200);
	USART_putstring(add_int(temp_result));
	_delay_ms(4000);
	
	PORTC &= ~(1<<PORTC1);
	PORTE &= ~(1<<PORTE3);
	_delay_ms(500);
	millis = 0;
	sendflag = 0;
}

void USART_init(void){
	UBRR0H = (uint8_t)(BAUD_PRESCALLER>>8);
	UBRR0L = (uint8_t)(BAUD_PRESCALLER);
	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

unsigned char USART_receive(void){
	while(!(UCSR0A & (1<<RXC0)));
	return UDR0;
}

void USART_send( unsigned char data){
	while(!(UCSR0A & (1<<UDRE0)));
	UDR0 = data;
}
void USART_putstring(char* StringPtr){
	while(*StringPtr != 0x00){
		USART_send(*StringPtr);
	StringPtr++;}
}

