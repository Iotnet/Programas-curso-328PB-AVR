#ifndef TMP102_H_DEVCUBE
#define TMP102_H_DEVCUBE

/*
 * @file ADS1115.h
 *
 *@author Written by Mohammed Asim Merchant
 *		 Created on 14/03/2019
 *
 *@Note	PIN CONFIGURATION
 *		ADS1115 SCL				---		I2C_SCL = PINB2
 *		ADS1115 SDA				---		I2C_SDA = PINB3
 *		ADS1115 ADDR			---		GND
 *		ADS1115 ALERT/DDRY		---		any I/O = PIND3
 *
 * @License MIT License
 *
 * Copyright (c) 2019 Mohammed Asim Merchant
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.

 *
 */

#include <avr/io.h>
#include <util/delay.h>
#include "I2CLib.h"

/************************************************************************/
/* TMP102 ADDR															*/
/************************************************************************/

#define TMP102_ADDR_GND (0b1001000)
#define TMP102_ADDR_VDD (0b1001001)
#define TMP102_ADDR_SDA (0b1001010)
#define TMP102_ADDR_SCL (0b1001011)

/************************************************************************/
/* TMP102 REGISTER														*/
/************************************************************************/

#define TMP102_REG_TEMPERATURE	0x00
#define TMP102_REG_CONFIG		0x01
#define TMP102_REG_LO_THRESH	0x02
#define TMP102_REG_HI_THRESH	0x03

/************************************************************************/
/* ADS1115 CONFIG REGISTER BIT NR										*/
/************************************************************************/

#define ADS1115_OS 			15
#define ADS1115_IMUX2 		14
#define ADS1115_IMUX1 		13
#define ADS1115_IMUX0 		12
#define ADS1115_PGA2 		11
#define ADS1115_PGA1 		10
#define ADS1115_PGA0 		9
#define ADS1115_MODE 		8
#define ADS1115_DR2 		7
#define ADS1115_DR1 		6
#define ADS1115_DR0 		5
#define ADS1115_COMP_MODE 	4
#define ADS1115_COMP_POL 	3
#define ADS1115_COMP_LAT 	2
#define ADS1115_COMP_QUE1 	1
#define ADS1115_COMP_QUE0	0

/************************************************************************/
/* ADS1115 CONFIG REGISTER BITS											*/
/************************************************************************/

// Bit 0-3
#define TMP102_NO_USED_BITS					(0x0000)

// Bit 4
#define TMP102_EXTENDED_MODE_ON				(0x0010)
#define TMP102_EXTENDED_MODE_OFF			(0x0000)

// Bit 5
#define TMP102_ALERT_BIT					(0x0020)

// Bit 6,7
#define TMP102_CONVERTION_RATE_025HZ		(0x0000)
#define TMP102_CONVERTION_RATE_1HZ			(0x0040)
#define TMP102_CONVERTION_RATE_4HZ			(0x0080)
#define TMP102_CONVERTION_RATE_8HZ			(0x00C0)

// Bit 8
#define TMP102_SHUTDOWN_OFF					(0x0000)
#define TMP102_SHUTDOWN_ON					(0x0100)

// Bit 9
#define TMP102_COMPARATOR_MODE				(0x0000)
#define TMP102_INTERRUPTOR_MODE				(0x0200)

// Bit 10
#define TMP102_POLARITY_LOW					(0x0000)
#define TMP102_POLARITY_HIGH				(0x0400)

// Bit 11,12
#define TMP102_FAULT_1			(0x0000)
#define TMP102_FAULT_2			(0x0800)
#define TMP102_FAULT_4			(0x1000)
#define TMP102_FAULT_6			(0x1800)

// Bit 13,14
#define TMP102_RESOLUTION					(0x6000)

// Bit 13,14
#define TMP102_ONE_SHOT_OFF					(0x0000)
#define TMP102_ONE_SHOT_ON					(0x8000)

#define I2C_WRITE_BIT		0
#define I2C_READ_BIT		1

#define bitRate				32


/************************************************************************/
/* TMP102 FUNCTIONS			                                        */
/************************************************************************/

uint8_t TMP102_write_register(uint8_t addr, uint8_t reg, uint16_t data);
uint16_t TMP102_read_register(uint8_t addr, uint8_t reg);
uint16_t TMP102_readtempC(uint8_t addr);

/**************************************************************************/
/*!
    @brief  write register of ADC
*/
/**************************************************************************/
uint8_t TMP102_write_register(uint8_t addr, uint8_t reg, uint16_t data)
{
	I2C_Start();
	I2C_Write((addr << 1) + I2C_WRITE_BIT);
	I2C_Write((uint8_t)reg);
	I2C_Write((uint8_t)(data >> 8));
	I2C_Write((uint8_t)(data & 0xFF));
	I2C_Stop();
	
	return 0;
}

/**************************************************************************/
/*!
    @brief  read register from ADC
*//**************************************************************************/
uint16_t TMP102_read_register(uint8_t addr, uint8_t reg)
{
	I2C_Start();
	I2C_Write((addr << 1) + I2C_WRITE_BIT);
	I2C_Write(reg);
	I2C_Stop();
	
	I2C_Start();
	I2C_Write((addr << 1) + I2C_READ_BIT);
	uint8_t msb = I2C_Read(1);
	uint8_t lsb = I2C_Read(0);
	I2C_Stop();
	
	uint16_t data = (msb << 8 | lsb);
	return data;
}

/**************************************************************************/
/*!
    @brief  read raw data from one channel of ADC
*/
/**************************************************************************/
uint16_t TMP102_readtempC(uint8_t addr)
{	
	uint16_t tmp_config = TMP102_ONE_SHOT_OFF	|
				 TMP102_RESOLUTION |
				 TMP102_FAULT_1 |	
				 TMP102_POLARITY_LOW | 
				 TMP102_COMPARATOR_MODE |
				 TMP102_SHUTDOWN_OFF |
				 TMP102_CONVERTION_RATE_4HZ |
				 TMP102_ALERT_BIT  |
				 TMP102_EXTENDED_MODE_OFF |
				 TMP102_NO_USED_BITS;
				 //FSR_6_144;	
	
	TMP102_write_register(addr, TMP102_REG_CONFIG, tmp_config);
	//_delay_ms(8);
	
	return TMP102_read_register(addr, TMP102_REG_TEMPERATURE) >> 0;
}


#endif /* ADS1115_H_DEVCUBE */